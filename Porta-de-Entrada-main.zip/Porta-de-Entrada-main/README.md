# Porta-de-Entrada

O projeto consiste na criação de uma plataforma gamificada educacional, voltada para os alunos do 3º ano do ensino médio integrado do Instituto Federal de Muzambinho para o ingresso no ensino superior. O sistema visa auxiliar os alunos na organização dos estudos e no desempenho para a preparação para o vestibular, consecutivamente oferecendo melhoria no monitoramento aos discentes, sendo uma plataforma de "cursinho" gratuita da instituição. 
